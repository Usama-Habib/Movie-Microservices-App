package com.usama.discoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServerForMovieCatalogApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
